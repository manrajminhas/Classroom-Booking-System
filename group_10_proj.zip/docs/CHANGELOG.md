# Introduction

This is where you record all of the meetings, add the notes for each meetings. 

### September 10, 2025

- Initial group forming

### September 17, 2025

- Discuss project requirements
- Discuss how to split work for Design I sprint
- Research Gitlab functionality and discuss who will be Maintainer of the project
- Begin working on PRD

### September 20, 2025

- Continue work on PRD and capture user stories, functional requirements, and QA scenarios as Gitlab issues
- Work on ADR documents
- Discuss potential milestones and deadlines for user stories

### September 23, 2025

- Discuss distribution of responsibilities for Implementation I phase
- Begin setting up Docker
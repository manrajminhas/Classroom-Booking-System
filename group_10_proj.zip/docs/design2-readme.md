For Design II, our team made the following changes:

- Reassigned due dates and group members to user stories
- Updated ADRs based on Design II spec and Design I feedback
- Linked ADRs to Gitlab issues based on Design I feedback
- Sketched out module and C&C views
- Identified and documented three technical debt items from Cycle I
- Reprioritized backlog based on new/amended work items
- Updated test plan based on Design I feedback
- Added specific tests for QA scenarios based on Design I feedback

Please note that we were a team of three for this phase; one of our group members dropped the class.